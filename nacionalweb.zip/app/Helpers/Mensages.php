<?php
//Mensajes OK...
define("OK_IST","Registro Insertado Correctamente.");
define("OK_UPT","Registro Actualizado Correctamente.");
define("OK_DEL","Registro Eliminado Correctamente.");
define('OK_LST','Registros Listados Correctamente.');


define("NOT_LISTED","No Hay Registros Que Mostrar.");
define("REG_NULL","No Existe Dicho Registro");
