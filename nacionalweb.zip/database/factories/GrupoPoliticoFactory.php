<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\GrupoPolitico;
use Faker\Generator as Faker;

$factory->define(GrupoPolitico::class, function (Faker $faker) {
    return [
        //
    ];
});
