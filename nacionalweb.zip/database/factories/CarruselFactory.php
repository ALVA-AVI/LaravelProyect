<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Carrusel;
use Faker\Generator as Faker;

$factory->define(Carrusel::class, function (Faker $faker) {
    return [
        //
    ];
});
