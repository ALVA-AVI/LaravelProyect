<footer>
    <div class="copyright">
      <p>copy right &copy 2020 - Restauracion Nacional</p>
    </div>
    <div class="social">
      <li class="support">
          <a href="https://es.wikipedia.org/wiki/Humberto_Lay_Sun">Humberto Lay</a>
        </li>
      <li class="face">
        <a href="https://www.facebook.com/mir.juntosporelcambio"><i class="fa fa-facebook"></i></a>
      </li>
      <li class="tweet">
        <a href="#"><i class="fa fa-twitter"></i></a>
      </li>
      <li class="linked">
        <a href="#"><i class="fa fa-linkedin-square"></i></a>
      </li>
    </div>
</footer>