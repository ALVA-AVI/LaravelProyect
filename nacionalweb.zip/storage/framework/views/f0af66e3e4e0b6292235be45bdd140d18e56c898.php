<div class="form-group">
    <?php echo Form::label('name','Tema ó Consulta'); ?>

    <?php echo Form::text('name',old('name'),['class'=>'form-control','placeholder'=>'Tema a brindar']); ?>

    <?php echo $errors->first('name','<small class="form-text text-danger">:message</small>'); ?>

</div><?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/tema/form/form.blade.php ENDPATH**/ ?>