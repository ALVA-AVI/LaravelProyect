
<div class="row">
    <div class="col">
        <div class="form-group">
            <?php echo Form::label('titulo','Titulo *'); ?>

            <?php echo Form::text('titulo',old('titulo'),['class'=>'form-control','placeholder'=>'Ingrese un Título','maxlength'=>'20']); ?>

            <?php echo $errors->first('titulo','<small class="form-text text-danger">:message</small>'); ?>

        </div>
    </div>
    <div class="col">
        <div class="form-group">
            <?php echo Form::label('category_id','Categoria *'); ?>

            <?php echo Form::select('category_id',$category,old('category'),['class'=>'form-control','placeholder'=>'Seleccione Categoría...']); ?>

            <?php echo $errors->first('category_id','<small class="form-text text-danger">:message</small>'); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col">
        <div class="form-group">
            <?php echo Form::label('resena','Reseña '); ?>

            <?php echo Form::textarea('resena',old('resena'),['id'=>'resena','rows'=>'4','class'=>'form-control']); ?>

            <?php echo $errors->first('resena','<small class="form-text text-danger">:message</small>'); ?>

        </div>
    </div>
    <div class="col">
        <div class="form-group">
            <?php echo Form::label('linkref','Agregar Referencias'); ?> 
            <?php echo Form::text('linkref',old('linkref'),['class'=>'form-control','placeholder'=>'http://ejemplo.org.pe - Tema']); ?>

        </div>
    </div>
</div>
<div class="form-group">
    <?php echo Form::file('image',['onchange'=>'validarImage();','id'=>'image']); ?>

</div>
<div class="col-lg-12">
    <div id="visorArchivo">
        <?php if(request()->routeis('banners.edit')): ?>
        <img src="<?php echo e($carrusel->image->url); ?>" alt="" class="rounded">                  
        <?php endif; ?>
    </div>
</div>


<?php $__env->startSection('scripts'); ?>
<script>
    function validarImage(){
        var archivoInput = document.getElementById('image');
        var archivoRuta = archivoInput.value;
        var extPermitidas = /(.jpeg|.JPEG|.JPG|.jpg|.png|.PNG)$/i;
        if(!extPermitidas.exec(archivoRuta)){
            alert('Asegurate de haber seleccionado una Imagen');
            archivoInput.value = '';
            return false;
        }else{
            if(archivoInput.files && archivoInput.files[0]){
                var visor = new FileReader();
                visor.onload = function(e){
                    document.getElementById('visorArchivo').innerHTML='<embed src="'+e.target.result+'">';
                };
                visor.readAsDataURL(archivoInput.files[0]);
            }
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/banner/form/form.blade.php ENDPATH**/ ?>