
<?php $__env->startSection('title','Editar Categoría'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">
        <a href="<?php echo e(route('categories.index')); ?>">Categoría</a>
    </li>
    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Registro de Categoría</h3>
        </div>
        <?php echo Form::model($categoria,['route'=>['categories.update',$categoria->id],'method'=>'PUT','files'=>true]); ?>

        <div class="card-body">
            <?php echo $__env->make('admin.categoria.form.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-danger float-right">Cancelar</a>
            <input type="submit" value="Actualizar" class="btn btn-primary">
        </div>
        <?php echo Form::close(); ?>

    </div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/categoria/edit.blade.php ENDPATH**/ ?>