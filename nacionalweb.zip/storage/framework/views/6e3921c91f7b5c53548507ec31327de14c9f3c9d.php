<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('img/2017/04/cropped-LOGO-270x270.png')); ?>" />
    <title><?php echo $__env->yieldContent('title','Partido Político Restauración Nacional Perú'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stilo092020.css')); ?>">
    <link rel="icon" href="<?php echo e(asset('img/2017/04/cropped-LOGO-32x32.png')); ?>" sizes="32x32">
    <link rel="icon" href="<?php echo e(asset('img/2017/04/cropped-LOGO-192x192.png')); ?>" sizes="192x192">
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>


</head>
<body>
    
    <?php echo $__env->make('layouts.partials._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--End Header-->
        <!-- Contenido-->
            <main role="main" class="container">
                <div class="container">
                    <?php echo $__env->yieldContent('contenido'); ?>
                </div>
            </main>
        <!--End Contenido-->



    
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</body>
</html>


<?php /**PATH C:\laragon\www\nacionalweb\resources\views/layouts/_layout.blade.php ENDPATH**/ ?>