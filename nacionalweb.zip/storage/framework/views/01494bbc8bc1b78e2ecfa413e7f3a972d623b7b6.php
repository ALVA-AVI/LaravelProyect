<!--div class="card-header">
    <h4 class="card-titble">Modulos</h4>
</div>
<ul class="list-group">
    @ foreach (getModuleCategorias as $item) 
        <li class="list-group-item"><a href=""></a></li>
    @ endforeach
</ul-->
<div class="card-header">
    <h4 class="card-titble">Modulos</h4>
</div>
<ul class="list-group">
    <?php $mod = getModulesArray();
        foreach ($mod as $key => $value) {?>
            <li class="list-group-item">
                <a href="<?php echo e($key == 1?route('web.index') : route('web.modulo',$key)); ?>"><?php echo e($value); ?></a>
            </li>
    <?php  }  ?>
</ul><?php /**PATH C:\laragon\www\nacionalweb\resources\views/web/weblayouts/_categorias.blade.php ENDPATH**/ ?>