<ul>
    <?php $mod = getModulesArray();
        foreach ($mod as $key => $value) {?>
            <li class="cat-item cat-item-6">
                <a href="<?php echo e(route('web.modulo',$key)); ?>"><?php echo e($value); ?></a>
            </li>
    <?php  }  ?>
</ul><?php /**PATH C:\laragon\www\nacionalweb\resources\views/layouts/_categoria.blade.php ENDPATH**/ ?>