<?php $__env->startSection('contenido'); ?>
<main class="formulario-center">
    <!-- Open Carrusel -->
<div class="slider">
    <div class="container">
        
        <div class="flexslider">
            <?php echo $__env->make('layouts.partials._banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<!-- End Carrusel ---->

<div class="container">
    <div class="row">
        <div class="col-lg-8 col-xs-12">
            <div class="container">
                <?php if($noticia != "" || $noticia != null): ?>
                <h4 class="card-subtitle mb-2 text-muted">Últimas Noticias</h4>
                <?php if(($noticia->image->url != "" || $noticia->image->url != null) && $noticia->category->module = 1): ?>
                <div class="cont-n-img">
                    <img width="619" height="347" src="<?php echo e(asset($noticia->image->url)); ?>" class="attachment-easthill-featured size-easthill-featured wp-post-image" alt="" sizes="(max-width: 619px) 100vw, 619px" />
                </div>
                <div class="text-holder">
                    <span class="cat-link">
                    <a class="category" href="category/sin-categoria/index.html"><?php echo e($noticia->category->name); ?></a>
                    </span>
                    <header class="entry-header">
                        <h2 class="entry-title">
                        <a href="<?php echo e(route('web.index')); ?>" rel="bookmark"><?php echo htmlspecialchars_decode($noticia->titulo); ?></a>
                        </h2>
                        <div class="entry-meta">
                            <span class="posted-on">
                                <i class="fa fa-calendar"></i>
                                <a href="noticias/index.html" rel="bookmark">
                                <time class="entry-date published" datetime="2017-05-12T11:55:40+00:00">
                                    publicado el  <?php echo e(date("j  F, Y",strtotime($noticia->fecha))); ?>

                                </time>
                                </a>
                            </span>
                            <span class="byline">
                                <i class="fa fa-user"></i>
                                <span class="author vcard">
                                    <a class="url fn n" href="author/admin/index.html">Admin</a>
                                </span>
                            </span>
                            <!--span class="comment">
                                <i class="fa fa-comment"></i>
                                <a href="noticias/index.html#respond">Leave a comment</a>
                            </span-->
                        </div>
                    </header>
                    <div class="entry-excerpt">
                    <p><?php echo htmlspecialchars_decode($noticia->resumen); ?></p>
                    </div>
                    <div class="entry-footer">
                        <a class="read-more" href="<?php echo e(route('web.show',$noticia->id)); ?>">Leer Mas...</a>
                    </div>
                </div>
                <?php else: ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="subtitle md-4">No hay Noticias por el Momento</h5>
                        </div>
                    </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <br>
            <br>
            <br>
            <div class="container">
                  <div class="card">
                    <div class="card-body">
                        <div class="card-title">
                            <header class="entry-header">
                                <h2 class="entry-title">
                                    <a href="historia-de-humberto-lay/index.html" rel="bookmark">Historia de Humberto Lay</a>
                                </h2>
                            </header>
                        </div>
                        <div class="card-text">
                            <div class="entry-excerpt">
                                <p>
                                    <a href="https://es.wikipedia.org/wiki/Humberto_Lay_Sun">Conocer más Humberto Lay</a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <img class="card-img-bottom" src="<?php echo e(asset('img/2017/04/foto_lay-1024x692.jpg')); ?>" alt="Card image cap">
                  </div>
            </div>
<br>
<br>
<br>

            <!--- Politica -->
            <div class="container">
                <div class="cont-n-img">
                    <a href="politica/index.html" class="post-thumbnail">
                        <img width="750" height="406" src="<?php echo e(asset('img/2017/04/cropped-PORTRAIT.jpg')); ?>" class="attachment-easthill-featured size-easthill-featured wp-post-image" alt="" sizes="(max-width: 750px) 100vw, 750px" />
                    </a>
                </div>
                <div class="text-holder">
                    <span class="cat-link">
                        <a class="category" href="category/politica/index.html">Política</a>
                    </span>
                    <header class="entry-header">
                        <h2 class="entry-title">
                            <a href="politica/index.html" rel="bookmark">Política</a>
                        </h2>
                        <div class="entry-meta">
                            <span class="posted-on">
                                <i class="fa fa-calendar"></i>
                                <a href="politica/index.html" rel="bookmark">
                                    <time class="entry-date published" datetime="2017-04-17T19:52:54+00:00">17 abril, 2017</time>
                                </a>
                            </span>
                            <span class="byline">
                                <i class="fa fa-user"></i>
                                <span class="author vcard">
                                    <a class="url fn n" href="author/admin/index.html">admin</a>
                                </span>
                            </span>
                            <!--span class="comment">
                                <i class="fa fa-comment"></i>
                                <a href="politica/index.html#respond">Leave a comment</a>
                            </span-->
                        </div>
                    </header>
                    <div class="entry-excerpt">
                        <p>Spot Restauración Nacional. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>
                    </div>
                    <div class="entry-footer">
                        <a class="read-more" href="politica/index.html">Ingresar &#8250;</a>
                    </div>
                </div>
            </div>
            <!-- End Politica --->

        </div>
        <div class="col-lg-4">
            <div class="">
                <div id="secondary" class="widget-area" role="complementary">
                    <div class="panel panel-primary">
                        <div class="panel-body">
                            <div class="form-group input-group">
                                <?php echo e(Form::label('Buscar :',null,array_merge(['class'=>'sr-only']))); ?>

                                <?php echo e(Form::text('buscar',null,array_merge(['class'=>'form-control','placeholder'=>'Buscar...']))); ?>

                                <?php echo e(Form::submit('Buscar',array_merge(['class'=>'input-group-append btn btn-primary']))); ?>

                            </div>
                        </div>
                    </div>
                    <aside id="recent-posts-2" class="widget widget_recent_entries">
                        <h2 class="widget-title">Publicaciones recientes</h2>
                        <ul>
					        <li>
				                <a href="<?php echo e(route('web.index')); ?>">Noticias</a>
						    </li>
					        <li>
				                <a href="http://restauracionnacional.org.pe/historia-de-humberto-lay/">Historia de Humberto Lay</a>
						    </li>
					        <li>
				                <a href="#">Elecciones 2017</a>
						    </li>
				        </ul>
                    </aside>

                    <aside id="archives-2" class="widget widget_archive">
                        <h2 class="widget-title">Archivos</h2>
                        <ul>
			                <!--li>
                                <a href="http://restauracionnacional.org.pe/2017/05/">mayo 2017</a>
                            </li>
	                        <li>
                                <a href="http://restauracionnacional.org.pe/2017/04/">abril 2017</a>
                            </li-->
		                </ul>
                    </aside>
                    <aside id="categories-2" class="widget widget_categories">
                        <h2 class="widget-title">Modulos</h2>
                        <?php echo $__env->make('layouts._categoria', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </aside>
                </div>
            </div>
        </div>
    </div>
</div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/index.blade.php ENDPATH**/ ?>