
<?php $__env->startSection('title', 'Noticias'); ?>
   
<?php $__env->startSection('contenido'); ?>
<main class="formulario-center">
    <div class="slider">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-lg-9">
                   <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if(($item->image->url != "" || $item->image->url != null) && $item->category->module == 1): ?>
                   <div class="card">
                       <div class="card-header">
                           <h4 class="card-title"><?php echo htmlspecialchars_decode($item->titulo); ?></h4>
                       </div>
                       <div class="card-body">
                           <div class="row">
                               <div class="col-lg-6">
                                   <img src="<?php echo e($item->image->url); ?>" class="card-img-top" alt="">
                                   <hr>
                                   <?php echo e($item->resumen); ?>

                                   <hr>
                                   <!--p class="lead">
                                       Archivos
                                   </p>
                                   <ul class="list-group list-group-horizontal-md">
                                       <li class="list-group-item"><a href="">Documento</a></li>
                                       <li class="list-group-item"><a href="">Imagen</a></li>
                                     </ul-->
                               </div>
                               <div class="col-lg-6">
                                   <?php echo htmlspecialchars_decode($item->contexto); ?>

                               </div>
                               
                           </div>
                       </div>
                       <div class="card-footer">
                           <div class="lead">
                               <p> publicado el <?php echo e(date("d - m - yy",strtotime($item->fecha))); ?></p>
                           </div>
                       </div>
                   </div>
                   <hr>
                   <?php endif; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    

                </div>
                <div class="col col-lg-3">
                    <div class="card">
                            <?php echo $__env->make('web.weblayouts._categorias', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <hr>
                    <h5>Mas Publicaciones</h5>
                    <div class="overflow-hidden">
                        <?php echo $__env->make('web.weblayouts._plusnoticias', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/web/noticias/index.blade.php ENDPATH**/ ?>