
<?php $__env->startSection('title','Géstion de Publicaciones'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Sección de Publicaciones</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('registros.create')); ?>" class="btn btn-tool">
                    <h6> Agregar <i class="fas fa-plus"></i></h6>
                </a>
                <!--button class="btn btn-tool" type="button" data-card-widget="collapse" data-toggle="tooltip" title="collapse">
                    <i class="fas fa-minus"></i>
                </button>
                <button class="btn btn-tool" type="button" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i>
                </button-->
            </div>
        </div>
        <div class="card-body table-responsive p-0" style="height: 300px">
            <table class="table table-head-fixed table-sm table-hover">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th>Titulo</th>
                        <th>Modulo</th>
                        <th>resumen</th>
                        <th>Fecha</th>
                        <th colspan="3">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($registro->id); ?></td>
                            <td><?php echo e($registro->titulo); ?></td>
                            <td>
                                <?php $__currentLoopData = getModulesArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($row == $registro->category->module): ?>
                                    <?php echo e($value); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                            <td><?php echo e($registro->resumen); ?></td>
                            <td><?php echo e(date("d/m/yy",strtotime($registro->fecha))); ?></td>
                            <td>
                                <a href="<?php echo e(route('registros.edit',$registro->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('registros.show',$registro->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-eye"></i></a>
                            </td>
                            <td>
                                <?php echo Form::open(['route'=>['registros.destroy',$registro->id],'method'=>'DELETE']); ?>

                                <button class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($registros->render()); ?>

        </div>
        <div class="card-footer">
            footer
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/registro/index.blade.php ENDPATH**/ ?>