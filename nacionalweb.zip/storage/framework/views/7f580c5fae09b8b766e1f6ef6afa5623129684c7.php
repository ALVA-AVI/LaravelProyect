<?php $__env->startSection('title','Detalles Publicación'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">
        <a href="<?php echo e(route('registros.index')); ?>">Publicaciones</a>
    </li>
    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Detalles de Publicaciones</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-8">
                    <!--Title-->
                    <h1 class="mt-4"><?php echo e($registro->titulo); ?></h1>
                    <!--Time-->
                    <div class="lead">
                        <p> publicado el <?php echo e(date("d - m - yy",strtotime($registro->fecha))); ?></p>
                    </div>
                    <?php if($registro->image->url != ""): ?>
                    <hr>
                        <p class="card-subtitle mb-2 text-muted">
                            <?php echo e($registro->resumen); ?>

                        </p>
                    <hr>
                    <!--Vista Previa de Imagen -->
                   <a href="<?php echo e($registro->image->url); ?>"> <img src="<?php echo e($registro->image->url); ?>" alt="" class="img-fluid-rounded"></a>
                    <?php endif; ?>
                    <hr>
                    <p class="lead">
                        <?php echo htmlspecialchars_decode($registro->contexto); ?>

                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="card-my-4">
                        <h5 class="card-header">Archivos PDF</h5>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <ul class="list-unstyled mb-0">
                                        <?php if($registro->archivo != ""): ?>
                                        <li><a href="<?php echo e(asset('storage/'.$registro->archivo)); ?>"> Documentos </a></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('registros.index')); ?>" class="btn btn-primary">Regresar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/registro/show.blade.php ENDPATH**/ ?>