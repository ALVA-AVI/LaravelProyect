
<?php $__env->startSection('title','Géstion de Categorías'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Sección de categorias</h3>
            <div class="card-tools">
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-tool">
                    <h6> Agregar <i class="fas fa-plus"></i></h6>
                </a>
                <!--button class="btn btn-tool" type="button" data-card-widget="collapse" data-toggle="tooltip" title="collapse">
                    <i class="fas fa-minus"></i>
                </button>
                <button class="btn btn-tool" type="button" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i>
                </button-->
            </div>
        </div>
        <div class="card-body table-responsive p-0" style="height: 300px">
            <!--a href="<?php echo e(route('categories.create')); ?>" class="m-2 float-right btn btn-primary">Crear</a-->
            <ul class="nav nav-tabs">
                <li class="nav item">
                    <a href="<?php echo e(route('categories.index')); ?>" class="nav-link">Todos</a>
                </li>
                <?php $__currentLoopData = getModulesArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('module',$module)); ?>" class="nav-link"><?php echo e($item); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <table class="table table-head-fixed table-sm table-hover">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th>Nombre</th>
                        <th>Modulo</th>
                        <!--th>Slug</th-->
                        <th colspan="2">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($categoria->id); ?></td>
                            <td><?php echo e($categoria->name); ?></td>
                            <td>
                                <?php $__currentLoopData = getModulesArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($row == $categoria->module): ?>
                                        <?php echo e($value); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <!--td><?php echo e($categoria->slug); ?></td-->
                            <td width="10px">
                                <a href="<?php echo e(route('categories.edit',$categoria->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></a>
                            </td>
                            <td width="10px">
                                <?php echo Form::open(['route'=>['categories.destroy',$categoria->id],'method'=>'DELETE']); ?>

                                <button class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($categorias->render()); ?>

        </div>
        <div class="card-footer">
            footer
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/categoria/index.blade.php ENDPATH**/ ?>