
<?php $__env->startSection('title','Temas Consultas'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-2 text-muted">Admision de Temas de Consulta</h4>
                        <div class="card-tools">
                            <a href="<?php echo e(route('temas.create')); ?>" class="btn btn-tool">
                                <h6> Agregar <i class="fas fa-plus"></i></h6>
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Tema</th>
                                    <th colspan="2">&nbsp;</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($tema->id); ?></td>
                                        <td><?php echo e($tema->name); ?></td>
                                        <td width=15px><a href="<?php echo e(route('temas.edit',$tema->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></a></td>
                                        <td width=15px><a href="<?php echo e(route('temas.destroy',$tema->id)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($temas->render()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/tema/index.blade.php ENDPATH**/ ?>