
<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/banner.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Vista Previa de Banner'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">
        <a href="<?php echo e(route('banners.index')); ?>">Banner's</a>
    </li>
    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="card">
                <div class="card-body">
                    <div class="col">
                        <img src="<?php echo e($carrusel->image->url); ?>" class="img-fluid" alt="Responsive image" />
                        <div class="content-text">
                            <div class="item-text">
                                <h2><?php echo e($carrusel->titulo); ?></h2>
                                <p><?php echo e($carrusel->resena); ?></p>
                                <?php $carrusel->linkref != ""? $link = explode('-',$carrusel->linkref):"";?>
                                <?php if($link !="" || $link != null): ?>
                                <a class="btn btn-secondary btn-sm float-right" href="<?php echo e($link[0]); ?>"><?php echo e($link[1]); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>                            
        </div>
        <a href="<?php echo e(route('banners.index')); ?>" class="btn btn-secondary btn-lg">Regresar</a>
    </div> 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/banner/show.blade.php ENDPATH**/ ?>