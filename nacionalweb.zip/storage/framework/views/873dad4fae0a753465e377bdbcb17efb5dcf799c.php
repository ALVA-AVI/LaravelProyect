
<?php $__env->startSection('title'); ?>
    <?php if(request()->routeIs('temas.create')): ?>
        Crear Temas Consulta
    <?php else: ?> 
        Actualizacion Tema de Consulta
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">
        <a href="<?php echo e(route('temas.index')); ?>">Temas Consulta</a>
    </li>
    <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col col-lg-7">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title mb-2 text-muted">
                            <?php if(request()->routeIs('temas.create')): ?>
                                Registro Temas de Consulta <?php else: ?> Editando de Tema de Consulta
                            <?php endif; ?>
                        </h4>
                    </div>
                        <?php if(request()->routeIs('temas.create')): ?>
                            <?php echo Form::open(['route'=>'temas.store','method'=>'POST','files'=>true]); ?>

                            <div class="card-body">
                                <?php echo $__env->make('admin.tema.form.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="card-footer">
                                <a href="<?php echo e(route('temas.index')); ?>" class="btn btn-danger float-right">Cancelar</a>
                                <input type="submit" value="Guardar" class="btn btn-primary">
                            </div>
                            <?php echo Form::close(); ?>

                        <?php else: ?>
                            <?php echo Form::model($tema,['route'=>['temas.update',$tema->id],'method'=>'PUT','files'=>true]); ?>

                            <div class="card-body">
                                <?php echo $__env->make('admin.tema.form.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="card-footer">
                                <a href="<?php echo e(route('temas.index')); ?>" class="btn btn-danger float-right">Cancelar</a>
                                <input type="submit" value="Actualizar" class="btn btn-primary">
                            </div>
                            <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/tema/tema.blade.php ENDPATH**/ ?>