<?php $__env->startSection('title','Documentos Publicados'); ?>

<?php $__env->startSection('contenido'); ?>
    <div class="formulario-center">
        <div class="slider">
            <div class="container">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-subtitle mb-2 text-muted">Documentos Publicados</h4>
                    </div>
                        <table class="table table-hover table-striped table-bordered">
                            <thead>
                                <th>Documento</th>
                                <th>Categoría</th>
                                <th>Fecha Publicación</th>
                                <th>Resumen</th>
                                <th colspan="2"></th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($row->category->module == 2): ?>
                                        <tr>
                                            <td><?php echo e($row->titulo); ?></td>
                                            <td><?php echo e($row->category->name); ?></td>
                                            <td><?php echo e(date("d F, yy",strtotime($row->fecha))); ?></td>
                                            <td><?php echo e($row->resumen); ?></td>
                                            <td><a target="_blank" href="<?php echo e(asset('storage/'.$row->archivo)); ?>" class="btn btn-secondary btn-sm left-right">Descargar <i class="fa fa-download"></i></a></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts._layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nacionalweb\resources\views/web/files/index.blade.php ENDPATH**/ ?>