<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="<?php echo e(asset('img/2017/04/cropped-PORTRAIT.jpg')); ?>" class="d-block w-100-r" alt="...">
        <div class="banner-text">
            <div class="text">
                <h2>Política</h2>
                <p>Spot Restauración Nacional. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>
                <a class="read-more" href="politica/index.html">Ingrese</a>
            </div>
        </div>
      </div>
      <?php if($carrusel != ""  || $carrusel != null): ?>
      <?php $__currentLoopData = $carrusel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item">
        <img src="<?php echo e($banner->image->url); ?>" class="d-block w-100-r" alt="...">
        <div class="banner-text">
          <div class="text">
            <h2><?php echo e($banner->titulo); ?></h2>
            <p><?php echo e($banner->resena); ?></p>
            <?php $banner->linkref != ""? $link = explode('-',$banner->linkref):"";?>
            <?php if($link !="" || $link != null): ?>
            <a class="read-more" href="<?php echo e($link[0]); ?>"><?php echo e($link[1]); ?></a>
            <?php endif; ?>
          </div>
        </div>
      </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
<?php /**PATH C:\laragon\www\nacionalweb\resources\views/layouts/partials/_banner.blade.php ENDPATH**/ ?>