<div class="form-group">
    <?php echo Form::label('name','Nombre *'); ?>

    <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Nombre de Categoría...','autocomplete'=>'off']); ?>

    <?php echo $errors->first('name','<small class="form-text text-danger">:message</small>'); ?>

</div>
<div class="form-group">
    <?php echo Form::label('module','Modulo *'); ?>

    <?php echo Form::select('module', getModulesArray(),null,['class'=>'form-control','placeholder'=>'Seleccione...']); ?>

    <?php echo $errors->first('module','<small class="form-text text-danger">:message</small>'); ?>

</div>


<?php /**PATH C:\laragon\www\nacionalweb\resources\views/admin/categoria/form/form.blade.php ENDPATH**/ ?>